package main

import (
    "flag"
    "fmt"
    "log"
    "net/http"
)

func main() {

    http.Handle("/", http.FileServer(http.Dir("./static")))

    var port = flag.Int("port", 80, "port to listen to")
    flag.Parse()

    fmt.Printf("Starting server, listen on port :%d\n", *port)

    log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", *port), nil))
}
